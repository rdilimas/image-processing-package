# image_processing_rdilimas

Description. 
The package image_processing_rdilimas is used to:
	Processing:
		- Histogram matching
		- Structural similarity
		- Resize image
	Utils:
		- Read image
		- Save image
		- plot image
		- plot result
		- plot histogram


	-

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_rdilimas

```bash
pip install image_processing_rdilimas
```

## Author
Robson Lima

## License
[MIT](https://choosealicense.com/licenses/mit/)